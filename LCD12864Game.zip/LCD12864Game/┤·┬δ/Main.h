#include <at89x52.h>
#include <math.h>

#define	uchar		unsigned char
#define	int8_t		signed char
#define	uint		unsigned int
#define	int16_t		signed int
#define	uint32_t	unsigned long int
