/********************************************************************/
/* ��    ��:TFT����--(T6963)										*/
/* �ӿڶ���:P00~P07--->D0~D7  LCDport								*/
/*          P30-->C/D   P31-->RD(low)   P32-->WR(low)   P33-->FS	*/
/*          ״̬��:STA7 STA6 STA5 STA4 STA3 STA2 STA2 STA1 STA0		*/
/********************************************************************/
#include "T6963.h"
#include "ASCII.h"
// ASCII ��ģ��ʾΪ8*16
const uchar code turnf[8] = {7,6,5,4,3,2,1,0};
// 0~9(8*16)���룬����˳���λ��ǰ
//const uchar code CHAR_16[][16]={
//{0x00,0x00,0x00,0x18,0x24,0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x24,0x18,0x00,0x00},/*"0",0*/
//{0x00,0x00,0x00,0x10,0x70,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x7C,0x00,0x00},/*"1",1*/
//{0x00,0x00,0x00,0x3C,0x42,0x42,0x42,0x04,0x04,0x08,0x10,0x20,0x42,0x7E,0x00,0x00},/*"2",2*/
//{0x00,0x00,0x00,0x3C,0x42,0x42,0x04,0x18,0x04,0x02,0x02,0x42,0x44,0x38,0x00,0x00},/*"3",3*/
//{0x00,0x00,0x00,0x04,0x0C,0x14,0x24,0x24,0x44,0x44,0x7E,0x04,0x04,0x1E,0x00,0x00},/*"4",4*/
//{0x00,0x00,0x00,0x7E,0x40,0x40,0x40,0x58,0x64,0x02,0x02,0x42,0x44,0x38,0x00,0x00},/*"5",5*/
//{0x00,0x00,0x00,0x1C,0x24,0x40,0x40,0x58,0x64,0x42,0x42,0x42,0x24,0x18,0x00,0x00},/*"6",6*/
//{0x00,0x00,0x00,0x7E,0x44,0x44,0x08,0x08,0x10,0x10,0x10,0x10,0x10,0x10,0x00,0x00},/*"7",7*/
//{0x00,0x00,0x00,0x3C,0x42,0x42,0x42,0x24,0x18,0x24,0x42,0x42,0x42,0x3C,0x00,0x00},/*"8",8*/
//{0x00,0x00,0x00,0x18,0x24,0x42,0x42,0x42,0x26,0x1A,0x02,0x02,0x24,0x38,0x00,0x00},/*"9",9*/
//{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x60,0x60,0x00,0x00},/*".",10*/
//{0x00,0x00,0x00,0x00,0x00,0x00,0x18,0x18,0x00,0x00,0x00,0x00,0x18,0x18,0x00,0x00},/*":",11*/
//{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},/*" ",12*/
//};

void delay_us(uint n)
{
	while(n--);
}

void delay_ms(uint n)
{
	while(n--)	delay_us(100);	//n*1ms
}

//**********************************
//	ָ����ݶ�д״̬���(STA1,STA0)
//**********************************
void Check_RW(void)
{
	uchar temp;
	
	LCDport = 0xff;
	Mod_Cmd();
	Wr_H();
	Rd_L();
	delay_us(1);
	do
	{
		temp = LCDport;
	}while(temp&0x03 != 0x03);
	Rd_H();
}

//**********************************
//	�����Զ���״̬���(STA2)
//**********************************
//void Check_AutoRd(void)
//{
//	uchar temp;
//  
//	LCDport = 0xff;
//	Mod_Cmd();
//	Wr_H();
//	Rd_L();
//	delay_us(1);
//	do
//	{
//		temp = LCDport;
//	}while(temp&0x04 != 0x04);
//	Rd_H();
//}

//**********************************
//	�����Զ�д״̬���(STA3)
//**********************************
void Check_AutoWr(void)
{
	uchar temp;
  
	LCDport = 0xff;
	Mod_Cmd();
	Wr_H();
	Rd_L();
	delay_us(1);
	do
	{
		temp = LCDport;
	}while(temp&0x08 != 0x08);
	Rd_H();
}

//**********************************
//	����/������״̬���(STA6)
//**********************************
//void Check_ScrPeek(void)
//{
//	uchar temp;
//  
//	LCDport = 0xff;
//	Mod_Cmd();
//	Wr_H();
//	Rd_L();
//	delay_us(1);
//	do
//	{
//		temp = LCDport;
//	}while(temp&0x40 != 0x40);
//	Rd_H();
//}

//**********************************
//	��Һ��д����
//**********************************
void LCD_WrData(uchar dataX)
{
	Check_RW();
	Mod_Data();
	Rd_H();
	Wr_L();
	LCDport = dataX;
 	delay_us(1);
	Wr_H();
}

//**********************************
//	��Һ��дָ��
//**********************************
void LCD_WrCmd(uchar cmd)
{
	Check_RW();
	Mod_Cmd();
	Rd_H();
	Wr_L();
	LCDport = cmd;
	delay_us(1);
	Wr_H();
}

//**********************************
//	д������ָ��
//**********************************
void LCD_WrCmd1(uchar dataX,uchar cmd)
{
	LCD_WrData(dataX);
	LCD_WrCmd(cmd);
}

//**********************************
//	д˫����ָ��
//**********************************
void LCD_WrCmd2(uchar data1,uchar data2,uchar cmd)
{
	LCD_WrData(data1);
	LCD_WrData(data2);
	LCD_WrCmd(cmd);
}

//**********************************
//	�Զ�д����
//**********************************
void AutoWr_Data(uchar dataX)
{
	Check_AutoWr();
	Rd_H();
	Mod_Data();
	Wr_L();
	LCDport = dataX;
	delay_us(1);
	Wr_H();
}

//**********************************
//	�Զ�������
//**********************************
//uchar AutoRd_Data(void)
//{
//	uchar temp;
//	
//	Check_AutoRd();
//	temp = LCDport;
//	return temp;
//}

//**********************************
//	CGROM list
//**********************************
void LCD_CGROM_list(void)
{
	uchar  i;
	uchar txt=0x00;		// --For test word ! 
	
	LCD_WrCmd2(LCD_T_BASE,0x00,LCM_ADD_POS);	// set display location on screen
	LCD_WrCmd(LCM_AUT_WR);	// set autowrite
	for(i=0;i<16*8;i++)
		AutoWr_Data(txt++);	// ȫ��дCGROM�ַ���--For test word ! 
	LCD_WrCmd(LCM_AUT_OVR);	// autowrite over
	LCD_WrCmd2(LCD_T_BASE,0x00,LCM_ADD_POS);	// ���õ�ַָ��--��ʡ�ԣ�
}

//**********************************
//	�ı�����
//**********************************
void LCD_Clear_text(void)
{
	uint i;
	
	LCD_WrCmd2(LCD_T_BASE,0x00,LCM_ADD_POS);	// set display location on screen
	LCD_WrCmd(LCM_AUT_WR);	// set autowrite
	for(i=0;i<LineChar*ColumnChar;i++)
		AutoWr_Data(0x00);	// �Զ�дCGROM��Ӧ�Ŀ��ַ�
	LCD_WrCmd(LCM_AUT_OVR);	// autowrite over
	LCD_WrCmd2(LCD_T_BASE,0x00,LCM_ADD_POS);	// ���õ�ַָ��--��ʡ�ԣ�
}

//**********************************
//	ͼ������
//**********************************
void LCD_Clear_graph(void)
{
	uint i;
	
	LCD_WrCmd2(LCD_G_BASE & 0xff,LCD_G_BASE>>8,LCM_ADD_POS);	// set display location on screen
	LCD_WrCmd(LCM_AUT_WR);	// set autowrite
	for(i=0;i<16*8*8;i++)
		AutoWr_Data(0x00);	// �Զ�д����
	LCD_WrCmd(LCM_AUT_OVR);	// autowrite over
	LCD_WrCmd2(LCD_G_BASE & 0xff,LCD_G_BASE>>8,LCM_ADD_POS);	// ������ʾ��ַ--��ʡ�ԣ�
}

//**********************************
//	��LCD�Դ�
//**********************************
void LCD_Clear_ram(void)
{
	uint i;
	
	LCD_WrCmd2(0x00,0x00,LCM_ADD_POS);
	LCD_WrCmd(LCM_AUT_WR);
	for(i=0;i<32767;i++)
		AutoWr_Data(0x00);	// autowrite datas
	LCD_WrCmd(LCM_AUT_OVR);	// autowrite over
	LCD_WrCmd2(0x00,0x00,LCM_ADD_POS);	// reset addr pointer--can cancel
}

//**********************************
//	��ʾ�ı��ַ�--ASCII��
//	line--�ַ���0~15,colu--�ַ���0~29
//	�������ַ���������
//**********************************
void LCD_ShowTxt(uchar line, uchar colu, uchar txtcode)
{
	uint  StartAddr;
	
	StartAddr = LCD_T_BASE + (line * LineChar) + colu;
	LCD_WrCmd2(StartAddr&0xff,StartAddr>>8,LCM_ADD_POS);// set display location on screen
	LCD_WrCmd1(txtcode,LCM_NOC_WR);						// CGROM����
}

//**********************************
//	�������ܣ���ʾ�ַ�����
//	line--�ַ���0~15,colu--�ַ���0~29
//	num:��ֵ(0~4294967295);
//	�������ַ���������
//**********************************
void LCD_ShowTxtNum(uchar line, uchar colu, float num)
{
	uint32_t z;
	uchar m,zs[8];			// �洢�������֣��������5λ����������3λС��
	int8_t i;
	
	z = num * 1000;			// ����С�����3λ
	
	/* �Ե͵���ȡ��λ�� */
	m=0;
	do
	{
		zs[m] = z % 10;
		z = z / 10;
		m++;
	}while( z != 0 );
	
	/* �Ըߵ�������ʾ */
	for(i=m-1;i>=0;i--)
	{
		if( i==2 )
		{
			LCD_ShowTxt(line, colu, 0x0e);		// ��λ��ǰ����С����
			colu++;
			LCD_ShowTxt(line, colu, 0x10+zs[i]);
		}
		else	LCD_ShowTxt(line, colu, 0x10+zs[i]);
		
		colu++;	// ����һ���ַ�λ
	}
}

//**********************************
//	��ʾ�ı��ַ���--ASCII��(8*8)
//	line--�ַ���0~15,colu--�ַ���0~29
//	�������ַ���������
//**********************************
void LCD_ShowTxtString(uchar line, uchar colu, char *txt)
{
	uint  StartAddr;
	
	StartAddr = LCD_T_BASE + (line * LineChar) + colu;
	LCD_WrCmd2(StartAddr&0xff,StartAddr>>8,LCM_ADD_POS);// set display location on screen
	LCD_WrCmd(LCM_AUT_WR);								// set autowrite
	while((*txt) != '\0')
		AutoWr_Data( (*txt++) - 0x20 );		// ASCII��תCGROM����
	LCD_WrCmd(LCM_AUT_OVR);					// autowrite over
}

//**********************************
//	��ʼ��LCD
//**********************************
void LCD_Init(void)
{
	LCD_WrCmd2(0x00,0x00,LCM_TXT_STP);		// �����ı���ʾ���׵�ַ(0x00)
	LCD_WrCmd2(LineChar,0x00,LCM_TXT_WID);	// �����ı���ʾ������
	LCD_WrCmd2(0x00,0x08,LCM_GRH_STP);		// ����ͼ����ʾ���׵�ַ(0x0800)
	LCD_WrCmd2(LineChar,0x00,LCM_GRH_WID);	// ����ͼ����ʾ������
	LCD_WrCmd(LCM_CUR_SHP | 0x07);			// ���ù����״(curtor sizes 8*7)
	LCD_WrCmd2(0x00,0x00,LCM_ADD_POS);		// ���ù��λ��
	LCD_WrCmd(LCM_MOD_OR);      			// ������ʾ��ʽ���ı�/ͼ�Ρ���
	LCD_WrCmd(LCM_DIS_SW | 0x0c);			// ����ͼ�Ļ��ģʽ
	LCD_Clear_text();		// ��ʡ�ԣ�
	LCD_Clear_graph();		// ��ʡ�ԣ�
	LCD_Clear_ram();		// All clear!!
}
//**********************************
// ��ʾͼ���ַ�����8*16
// line--������0~127,colu--�ַ���0~15
// �������У��У��ַ����룬��ʾģʽ(����/����)
//**********************************
void LCD_ShowChar(uchar line, uchar colu, uchar charcode, uchar dismode)
{
 uchar i;
 uint StartAddr;
 
 StartAddr = LCD_G_BASE + (line * LineChar) + colu;
 for(i=0;i<16;i++)
 {
  LCD_WrCmd2(StartAddr & 0xff,StartAddr>>8,LCM_ADD_POS); // set display location on screen
  
  if(dismode)
	LCD_WrCmd1( CHAR_16[charcode][i], LCM_NOC_WR);
  else
	LCD_WrCmd1(~CHAR_16[charcode][i], LCM_NOC_WR);
  
  StartAddr += LineChar;
 }
}

//**********************************
//	????:??????(8*16)
//	????:x,y :????
//	num:??(0~4294967295);
//	??:?,?,??,????(??/??)
//**********************************
//void LCD_ShowNum16(uchar line, uchar colu, float num, uchar dismode)
//{
//	uint32_t z;
//	uchar m,zs[8];	// ??????,????5???,??3???
//	int8_t i;		// ?????
//	
//	z = num * 1000;	// ??????3?
//	
//	/* ???????? */
//	m=0;
//	do
//	{
//		zs[m] = z % 10;
//		z = z / 10;
//		m++;
//	}while( z != 0 );
//	
//	/* ??????? */
//	for(i=m-1;i>=0;i--)
//	{
//		if(i==2)
//		{
//			LCD_ShowChar(line, colu, 10, dismode);		// ?????????
//			colu++;
//			LCD_ShowChar(line, colu, zs[i], dismode);
//		}
//		else	LCD_ShowChar(line, colu, zs[i], dismode);
//		
//		colu++;	// ???????
//	}
//}

//**********************************
//	??????,?16*16
//	LCM disply one chinese charactor  16*16
//	line--???0-127,	colu--???0-15
//	?:????:??,????,??????
//	??:?,?,????,????
//**********************************
void LCD_ShowHZ(uchar line, uchar colu, uchar hzcode, uchar dismode)
{
	uchar i;
	uint StartAddr;
	
	StartAddr = LCD_G_BASE + (line * LineChar) + colu;
	
	/* ?????? */
	for(i=0;i<8;i++)
	{
		LCD_WrCmd2(StartAddr & 0xff,StartAddr>>8,LCM_ADD_POS);	// set display location on screen
		LCD_WrCmd(LCM_AUT_WR);									// set autowrite
		if(dismode)
		{
			AutoWr_Data( HZK_16x16[hzcode*2][i*2]);
			AutoWr_Data( HZK_16x16[hzcode*2][i*2+1]);
		}
		else
		{
			AutoWr_Data( ~HZK_16x16[hzcode*2][i*2]);
			AutoWr_Data( ~HZK_16x16[hzcode*2][i*2+1]);
		}
		
		LCD_WrCmd(LCM_AUT_OVR);		// autowrite over
		StartAddr += LineChar;
	}

	/* ?????? */
	for(i=0;i<8;i++)
	{
		LCD_WrCmd2(StartAddr & 0xff,StartAddr>>8,LCM_ADD_POS);	// set display location on screen
		LCD_WrCmd(LCM_AUT_WR);									// set autowrite
		if(dismode)
		{
			AutoWr_Data( HZK_16x16[hzcode*2+1][i*2]);
			AutoWr_Data( HZK_16x16[hzcode*2+1][i*2+1]);
		}
		else
		{
			AutoWr_Data( ~HZK_16x16[hzcode*2+1][i*2]);
			AutoWr_Data( ~HZK_16x16[hzcode*2+1][i*2+1]);
		}
		
		LCD_WrCmd(LCM_AUT_OVR);		// autowrite over
		StartAddr += LineChar;
	}
}

void Show_Bmp_56x56(uchar x, uchar y, unsigned char image[]){
	unsigned int StartAddr, i;
	StartAddr = LCD_G_BASE + (x * LineChar) + y;
	LCD_WrCmd2(StartAddr&0xFF, StartAddr>>8, LCM_ADD_POS);
	LCD_WrCmd(LCM_AUT_WR);
	for (i = 0; i < 392; i++){
		if (i % 7 != 0){
			AutoWr_Data(image[i]);
		}
		else{
			LCD_WrCmd(LCM_AUT_OVR);		// autowrite over
			StartAddr += LineChar;
			LCD_WrCmd2(StartAddr&0xFF, StartAddr>>8, LCM_ADD_POS);
			LCD_WrCmd(LCM_AUT_WR);
			AutoWr_Data(image[i]);
		}
	}
}

void Show_Bmp_240x33(uchar x, uchar y, unsigned char image[]){
	unsigned int StartAddr, i;
	StartAddr = LCD_G_BASE + (x * LineChar) + y;
	LCD_WrCmd2(StartAddr&0xFF, StartAddr>>8, LCM_ADD_POS);
	LCD_WrCmd(LCM_AUT_WR);
	for (i = 0; i < 990; i++){
		if (i % 30 != 0){
			AutoWr_Data(image[i]);
		}
		else{
			LCD_WrCmd(LCM_AUT_OVR);		// autowrite over
			StartAddr += LineChar;
			LCD_WrCmd2(StartAddr&0xFF, StartAddr>>8, LCM_ADD_POS);
			LCD_WrCmd(LCM_AUT_WR);
			AutoWr_Data(image[i]);
		}
	}
}
void Show_Bmp_240x50(uchar x, uchar y, unsigned char* image){
	unsigned int StartAddr, i;
	StartAddr = LCD_G_BASE + (x * LineChar) + y;
	LCD_WrCmd2(StartAddr&0xFF, StartAddr>>8, LCM_ADD_POS);
	LCD_WrCmd(LCM_AUT_WR);
	for (i = 0; i < 1500; i++){
		if (i % 30 != 0){
			AutoWr_Data(image[i]);
		}
		else{
			LCD_WrCmd(LCM_AUT_OVR);		// autowrite over
			StartAddr += LineChar;
			LCD_WrCmd2(StartAddr&0xFF, StartAddr>>8, LCM_ADD_POS);
			LCD_WrCmd(LCM_AUT_WR);
			AutoWr_Data(image[i]);
		}
	}
}

void Show_Bmp_72x41(uchar x, uchar y, unsigned char* image){
unsigned int StartAddr, i;
	StartAddr = LCD_G_BASE + (x * LineChar) + y;
	LCD_WrCmd2(StartAddr&0xFF, StartAddr>>8, LCM_ADD_POS);
	LCD_WrCmd(LCM_AUT_WR);
	for (i = 0; i < 353; i++){
		if (i % 9 != 0){
			AutoWr_Data(image[i]);
		}
		else{
			LCD_WrCmd(LCM_AUT_OVR);		// autowrite over
			StartAddr += LineChar;
			LCD_WrCmd2(StartAddr&0xFF, StartAddr>>8, LCM_ADD_POS);
			LCD_WrCmd(LCM_AUT_WR);
			AutoWr_Data(image[i]);
		}
	}
}

void Show_Bmp_80x80(uchar x, uchar y, unsigned char* image){
unsigned int StartAddr, i;
	StartAddr = LCD_G_BASE + (x * LineChar) + y;
	LCD_WrCmd2(StartAddr&0xFF, StartAddr>>8, LCM_ADD_POS);
	LCD_WrCmd(LCM_AUT_WR);
	for (i = 0; i < 800; i++){
		if (i % 10 != 0){
			AutoWr_Data(image[i]);
		}
		else{
			LCD_WrCmd(LCM_AUT_OVR);		// autowrite over
			StartAddr += LineChar;
			LCD_WrCmd2(StartAddr&0xFF, StartAddr>>8, LCM_ADD_POS);
			LCD_WrCmd(LCM_AUT_WR);
			AutoWr_Data(image[i]);
		}
	}
}

/*****************************
 ??
 ??xy:??????
 X=[0,239];Y=[0,127]
 S????:1-??,0-???
******************************/
void DrawPoint(uchar x,uchar y,uchar s)
{
    uchar temp;
	
    temp = x >> 3;				//?Y??????
    SetPos(y,temp); 			//????
    temp = turnf[ x & 0x07 ];
	temp = temp | 0xf0 | (s<<3);//???????,D3?1
    LCD_WrCmd(temp);
}

/************************/
/* ??????			*/
/* ??xy:??????	*/
/************************/
void SetPos(uchar x, uchar y)
{
	uint StartAddr;
	
	StartAddr = LCD_G_BASE + (x * LineChar) + y;
	LCD_WrCmd2(StartAddr & 0xff, StartAddr>>8, LCM_ADD_POS);
}

/********************************************/
/* ?????????,??????aX+bY=1	*/
/* ??xy:??????						*/
/* X=[0,239];Y=[0,127]						*/
/********************************************/
void Linexy(uchar x0,uchar y0,uchar xt,uchar yt,uchar s)
{
    register uchar t;
    int16_t xerr=0,yerr=0;
    int16_t delta_x,delta_y,distance;
    int16_t incx,incy,uRow,uCol;
	
    delta_x = xt-x0;	// ??????
    delta_y = yt-y0;
    uRow = x0;
    uCol = y0;
    if(delta_x>0)
    {
        incx = 1;		// ??????
    }
    else if( delta_x==0 )
    {
        incx=0;			// ???
    }
    else
    {
        incx = -1;
        delta_x = -delta_x;
     
    }
    if(delta_y>0)
    {
        incy = 1;
    }
    else if( delta_y==0 ) 
    {
        incy = 0;		// ???
    }
    else 
    {
        incy = -1;
        delta_y = -delta_y;
    }
    if( delta_x > delta_y ) 
    {
        distance = delta_x;	// ?????????
    }
    else
    {
        distance = delta_y;
    }
    for( t=0;t <= distance+1; t++ )	// ????
    { 
        DrawPoint(uRow,uCol,s);		// ??
        xerr += delta_x;
        yerr += delta_y;
        if( xerr > distance )
        {
            xerr -= distance;
            uRow += incx;
        }
        if( yerr > distance )
        {
            yerr -= distance;
            uCol += incy;
        }
    }
}
/********************************************/
/* ??????(X-Ox)^2+(Y-Oy)^2=Rx^2		*/
/********************************************/
void DrawCircle(uchar Ox,uchar Oy,uchar R,uchar s)
{
    uint xx,rr;
    uint xt,yt;
    uint rs,row,col;
	
    yt = R;
    rr = (uint)R*R + 1;	// ??1 ????
    rs = (yt+(yt>>1)) >> 1;	// (*0.75)??1/8????
    for(xt=0;xt<=rs;xt++)
    {
        xx = xt*xt;
        while( (yt*yt)>(rr-xx) )
        {
            yt--;
        }
        row = Ox+xt; // ????
        col = Oy-yt;
        DrawPoint(row,col,s);
        row = Ox-xt; // ????
        DrawPoint(row,col,s);
        col = Oy+yt; // ????
        DrawPoint(row,col,s);
        row = Ox+xt; // ????
        DrawPoint(row,col,s);
        /***************45???????***************/
        row = Ox+yt; // ????
        col = Oy-xt;
        DrawPoint(row,col,s);
        row = Ox-yt; // ????
        DrawPoint(row,col,s);
        col = Oy+xt; // ????
        DrawPoint(row,col,s);
        row = Ox+yt; // ????
        DrawPoint(row,col,s);
    }
}
